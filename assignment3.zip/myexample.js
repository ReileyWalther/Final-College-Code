/* file: myexample.js
 */

let answers = [
    ['D','A','A','C','A','B','A','C','D','B','C','D','A','D','C','C','B','D','A','D']
];

module.exports = { answers };
